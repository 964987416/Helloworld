export const WINDOW = typeof window !== 'undefined' ? window : {};
export const NAMESPACE = 'distpicker';
export const EVENT_CHANGE = 'change';
